package negocio;

public class Equipo{
	private String liga, pais, continente;

	public Equipo(String liga, String pais, String continente){
		this.liga = liga;
		this.pais = pais;
		this.continente = continente;
	}

	@Override
	public String toString(){
		return getLiga() + "," + getPais() + "," + getContinente(); 
	}

	public String getLiga(){
		return liga;
	}

	public String getPais(){
		return pais;
	}

	public String getContinente(){
		return continente;
	}
}
