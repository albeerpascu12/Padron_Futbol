package negocio;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;

public class Futbol{
	private ArrayList<Equipo> listaEquipos = new ArrayList<>();

	public Futbol(){
		cargarEquipos();
	}

	private void cargarEquipos(){
		Scanner sc = null;
		try{
			File fichero = new File("futbol.csv");
			//Crea el fichero si no existe
			fichero.createNewFile();
			sc = new Scanner(fichero);
			sc.useDelimiter(",|\n");
			while(sc.hasNext()){
				listaEquipos.add(new Equipo(sc.next(), sc.next(), sc.next()));
			}
		}catch(IOException ex){
			System.out.println("Error en la lectura del fichero de equipos.");
			System.out.println("A continuación se muestra más información:");
			System.out.println(ex);
		}finally{
			if (sc != null) sc.close();
		}

	}

	public void annadir(Equipo equipo){
		listaEquipos.add(equipo);
		volcarEquipos();
	}

	private void volcarEquipos(){
		FileWriter fw = null;
		try{
			fw = new FileWriter("futbol.csv");
			for(Equipo equipo : listaEquipos){
				fw.write(equipo.getLiga() + "," + equipo.getPais() + "," + equipo.getContinente()+"\n");
			}
		}catch(IOException ex){
			System.out.println("No se ha podido añadir el nuevo equipo. Error en la escritura del fichero");
			System.out.println("A continuación se muestra más información:");
			System.out.println(ex);
		}finally{
			try{
				if (fw != null) fw.close();
			}catch(IOException ex){
				System.out.println(ex);
			}
		}
	}

	@Override
        public String toString(){
		StringBuilder strEquipos = new StringBuilder();
		for(Equipo equipo : listaEquipos) strEquipos.append(equipo + "\n"); 
		return strEquipos.toString();
	}	
}
